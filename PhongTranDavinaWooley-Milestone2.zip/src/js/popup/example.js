export default function () {
  alert("hello! (find me on src/js/popup/example.js)");
};
